"""Read-only availability check. No network, installs, or user-file discovery."""
from pathlib import Path
import importlib.util
import json
import sys
import zipfile


def main():
    root = Path(__file__).resolve().parents[1]
    missing = [p for p in ['data/indice.json', 'data/indice_proyectos.json',
               'scripts/generar_guia.py', 'scripts/validar_guia.py',
               'assets/GFPI-F-135 Formato Guia de Aprendizaje.docx']
               if not (root / p).is_file()]
    result = {'python': sys.version.split()[0], 'recursos_disponibles': not missing,
              'faltantes': missing, 'pdfplumber_disponible': importlib.util.find_spec('pdfplumber') is not None,
              'red_requerida': False, 'clave_api_requerida': False}
    if not missing:
        for key, index in [('programas', 'indice.json'), ('proyectos', 'indice_proyectos.json')]:
            items = json.loads((root / 'data' / index).read_text(encoding='utf-8'))
            result[key] = len(items)
            for item in items:
                if not (root / 'data' / item['archivo']).is_file():
                    missing.append(item['archivo'])
        with zipfile.ZipFile(root / 'assets' / 'GFPI-F-135 Formato Guia de Aprendizaje.docx') as z:
            result['plantilla_zip_integra'] = z.testzip() is None
    result['recursos_disponibles'] = not missing
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if not missing and result.get('plantilla_zip_integra') else 1


if __name__ == '__main__':
    raise SystemExit(main())
