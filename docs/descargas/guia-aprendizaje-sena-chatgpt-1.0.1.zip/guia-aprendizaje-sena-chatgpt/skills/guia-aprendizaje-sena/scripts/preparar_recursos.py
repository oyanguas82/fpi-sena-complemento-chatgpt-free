"""Restore the pinned runtime when the host does not mount plugin files."""
from pathlib import Path, PurePosixPath
import hashlib
import io
import tempfile
import urllib.request
import zipfile

URL_RECURSOS = 'https://oyanguas82.github.io/fpi-sena-complemento-chatgpt-free/descargas/guia-aprendizaje-sena-chatgpt-1.0.0.zip'
SHA256_RECURSOS = '4363b615ebd43f599bd9c4bc561c129392f22eea91da209c4782c99d9aa71e7d'
PREFIJO = ('guia-aprendizaje-sena-chatgpt', 'skills', 'guia-aprendizaje-sena')


def preparar_recursos(archivo_zip=None, destino=None):
    """Use one supplied ZIP or the pinned release; never scan user files."""
    if archivo_zip is not None:
        archivo_zip = Path(archivo_zip)
        if archivo_zip.stat().st_size > 6 * 1024 * 1024:
            raise ValueError('El archivo excede el tamaño esperado.')
        contenido = archivo_zip.read_bytes()
    else:
        with urllib.request.urlopen(URL_RECURSOS, timeout=20) as r:
            contenido = r.read(6 * 1024 * 1024 + 1)
    if hashlib.sha256(contenido).hexdigest() != SHA256_RECURSOS:
        raise ValueError('El ZIP no coincide con la versión revisada. No se ejecutará su contenido.')
    archivos = []
    with zipfile.ZipFile(io.BytesIO(contenido)) as z:
        if len(z.infolist()) > 300 or sum(i.file_size for i in z.infolist()) > 64 * 1024 * 1024:
            raise ValueError('Inventario del ZIP no permitido.')
        for i in z.infolist():
            p = PurePosixPath(i.filename)
            if p.is_absolute() or '..' in p.parts or '\\' in i.filename or ':' in i.filename:
                raise ValueError('Ruta del ZIP no permitida.')
            if (i.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError('El ZIP contiene un enlace simbólico.')
            if i.is_dir() or tuple(p.parts[:3]) != PREFIJO or len(p.parts) < 5:
                continue
            relativo = Path(*p.parts[3:])
            if relativo.parts[0] in {'scripts', 'assets', 'data', 'references'}:
                archivos.append((relativo, z.read(i)))
    if not archivos:
        raise ValueError('El ZIP no contiene los recursos de la guía.')
    padre = Path(destino).resolve() if destino else Path(tempfile.gettempdir()).resolve()
    padre.mkdir(parents=True, exist_ok=True)
    guia = Path(tempfile.mkdtemp(prefix='guia-runtime-', dir=padre)).resolve()
    for relativo, datos in archivos:
        salida = (guia / relativo).resolve()
        if not salida.is_relative_to(guia):
            raise ValueError('Ruta de salida no permitida.')
        salida.parent.mkdir(parents=True, exist_ok=True)
        salida.write_bytes(datos)
    for requerido in ['scripts/generar_guia.py', 'scripts/validar_guia.py', 'data/indice.json',
                      'assets/GFPI-F-135 Formato Guia de Aprendizaje.docx']:
        if not (guia / requerido).is_file():
            raise ValueError('Falta un recurso requerido: ' + requerido)
    return guia


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archivo', help='Ruta exacta de un ZIP adjunto por el usuario')
    parser.add_argument('--destino', help='Carpeta escribible donde crear un directorio aislado')
    args = parser.parse_args()
    print(preparar_recursos(args.archivo, args.destino))
